<?php

function getSSlPage($url){

  $curl = curl_init();
  curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
  curl_setopt($curl, CURLOPT_HEADER, false);
  curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
  curl_setopt($curl, CURLOPT_URL, $url);
  curl_setopt($curl, CURLOPT_REFERER, $url);
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
  $str = curl_exec($curl);
  curl_close($curl);
  return $str;

}

class caso{
  public $cedula;
    public $nombre;
    public $apellidos;
    public $ciudad;
    public $pais;
    public $longitud;
    public $latitud;
    public $comentario;
    public $Zodiaco;
    public $fechaNacimiento;
      public $FechaContageo;
      public $foto;


}
class obj_user{
  public $id;
  public $user_email;
  public $user_password;
}

class obj_login{
  public $user_email;
  public $user_password;
}


class wan_noticias{

  public $id;
  public $titulo;
  public $resumen;
  public $contenido;
  public $foto;
  public $fechaPublicacion;

}
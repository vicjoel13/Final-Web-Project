<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
    $this->load->helper('entidadCaso');

	}

	function index()
  {
    $this->load->view('index');
  }

  function login(){
    $this->load->view('login');
  }
  function agregarC(){
    $this->load->view('agregarC');
  }
  function agregarU($id=0){
    $this->load->view('agregarU',array('id'=>$id));
  }
  function MostrarC($id=0){
    $this->load->view('MostrarC',array('id'=>$id));
  }
  function suscribete(){
    $this->load->view('suscribete');
  }
  function estadistica(){
    $this->load->view('Estadistica');
  }

  function logeado(){
    $this->load->view('MenuA');
  }
  function agregarN($id=0){
    $this->load->view('agregarN',array('id'=>$id));
  }
  function noticias(){
    $this->load->view('noticias');
  }
  function noticiasU(){
    $this->load->view('noticiasU');
  }

  function NoticiaD($id=0){
    $this->load->view('NoticiaD',array('id'=>$id));
  }



}

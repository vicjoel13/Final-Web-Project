<?php plantilla::aplicar();?>
<?php
$CI=&get_instance();

$list = new obj_login();

if($_POST){
    $usuario = $_POST['user_email'];
    $pass = $_POST['user_password'];
    $rs = $CI->db->query("select * from login where user_email = '$usuario' and user_password = '$pass'")->result_array();

    if(count($rs) == 1){
      redirect(base_url().'welcome/logeado');
    }else{
        echo "<script>alert('no existe'); </script>";
    }
}
?>

<div class="login-clean">
        <form method="post">
            <h2 class="sr-only">Login Form</h2>
            <div class="illustration"><i class="icon ion-ios-navigate"></i></div>
            <div class="form-group"><label for="email">Email</label><input class="form-control" type="email" id="user_email" name="user_email"></div>
                        <div class="form-group"><label for="email">Contraseña</label><input class="form-control" type="password" id="user_password" name="user_password"></div>
            <div class="form-group"><button class="btn btn-primary btn-block" id="login" type="submit">Log In</button></div>
        </form>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pikaday/1.6.1/pikaday.min.js"></script>
    <script src="assets/js/script.min.js"></script>
<?php plantilla::aplicar();
$CI=&get_instance();


?>
    <main class="page lanidng-page">
        <section class="portfolio-block block-intro">
            
                <div class="about-me" >
                    <h3>Mapa de Datos Confirmados&nbsp;</h3><div id="mapid" style=" height: 500px; width: 100%" ></div></div>
          
        </section>
        <section>
        <div class="container">
        <div class="container">
                <div class="heading">
                    <h2>Noticias</h2>
                </div>
                <div class="row">
                <?php 
                    $CI =& get_instance();
                    $rs = $CI->db->query('select * from noticias ORDER BY id DESC LIMIT 3')->result_array();

                    foreach($rs as $fila){
                        $url=base_url("welcome/NoticiaD/{$fila['id']}");
                        echo "
                        <div class='col-md-12 col-lg-4'>
                        <div class='card border-0'><a href='{$url}'><img src='{$fila['foto']}' height='300px' alt='Card Image' class='card-img-top scale-on-hover'></a>
                            <div class='card-body'>
                                <h6>{$fila['titulo']}</h6>
                                <p class='text-muted card-text'>{$fila['resumen']}</p>
                            </div>
                        </div>
                    </div>
                        
                        ";

                        
                    }
                ?>
                 
                    </div>
                </div>
            </div>
        </section>
        <section class="portfolio-block skills">
            <div class="container">
                <div class="heading">
                    <h2>DEVELOPERS</h2>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card special-skill-item border-0">
                            <div class="card-header bg-transparent border-0"><i class="icon ion-ios-star-outline"></i></div>
                            <div class="card-body">
                                <h3 class="card-title">Jorge Saldivar</h3>
                                <p class="card-text">Estudiante de Software
                                                    <br>Papa de Jhonni</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card special-skill-item border-0">
                            <div class="card-header bg-transparent border-0"><i class="icon ion-ios-lightbulb-outline"></i></div>
                            <div class="card-body">
                                <h3 class="card-title">Victor Jimenez</h3>
                                <p class="card-text">Estudiante de Software
                                                    <br>Papa de Wander
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card special-skill-item border-0">
                            <div class="card-header bg-transparent border-0"><i class="icon ion-ios-gear-outline"></i></div>
                            <div class="card-body">
                                <h3 class="card-title">Wander Nova</h3>
                                <p class="card-text">Estudiante de Software
                                <br>Papa de Ismael
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <script>
      var mymap = L.map('mapid').setView([18.47460, -70.01211], 13);
  L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}', {
    attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
    maxZoom: 18,
    id: 'mapbox/streets-v11',
    tileSize: 512,
    zoomOffset: -1,
    accessToken: 'pk.eyJ1Ijoidmljam9lbDEzIiwiYSI6ImNrN28xazQwNTA0bnYzaHAwaHh6NnpqczIifQ.S9dQYbFdkeUWi75cYqTm1w'

}).addTo(mymap);

<?php
$CI =& get_instance();
$rs = $CI->db->get('casos')->result_array();

foreach($rs as $fila){
    $url =  base_url("welcome/MostrarC/{$fila['id']}");
echo "
  var marker = L.marker([{$fila['latitud']},{$fila['longitud']}]).addTo(mymap);
  marker.bindPopup('<b>Caso '+{$fila['id']}+'!</b><br>'+'{$fila['nombre']}'+'!<br>'+'{$fila['comentario']}'+'<br><a class='+'nav-link'+' href='+'{$url}'+'>Ver Caso</a>'+'.').openPopup();
 
  function onMapClick(e) {
      alert('You clicked the map at ' + e.latlng);
  }
";
}

?>

function agrgar(latitud,logitud,id,description){
var marker = L.marker([latitud,logitud]).addTo(mymap);
marker.bindPopup("<b>Caso "+id+"!</b><br>"+description+".").openPopup();
function onMapClick(e) {
    alert("You clicked the map at " + e.latlng);
}
}
mymap.on('click', onMapClick);
var popup = L.popup();
//19.460942, -67.765669

function onMapClick(e) {
    popup
        .setLatLng(e.latlng)
        .setContent("You clicked the map at " + e.latlng.toString())
        .openOn(mymap);
}

mymap.on('click', onMapClick);
    </script>

<style>
.portfolio-block.projects-cards .card img{box-shadow:0 2px 10px rgba(0,0,0,.15)}.portfolio-block.projects-cards a img{transition:.5s ease}@media (min-width:576px){.scale-on-hover:hover{-webkit-transform:scale(1.05);transform:scale(1.05);box-shadow:0 10px 10px rgba(0,0,0,.15)!important}}.card-img-top{width:100%;border-top-left-radius:calc(.25rem - 1px);border-top-right-radius:calc(.25rem - 1px)}img,svg{vertical-align:middle}img{border-style:none}.portfolio-block.projects-cards a{color:#212529}a:hover{color:#0075c1;text-decoration:underline}a{color:#0ea0ff;text-decoration:none;background-color:transparent;-webkit-text-decoration-skip:objects}.portfolio-block.projects-cards .card-body{text-align:center}.card-body{-ms-flex:1 1 auto;flex:1 1 auto;padding:1.25rem}
</style>
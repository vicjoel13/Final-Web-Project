<?php
plantilla::aplicar();
if(isset($_POST['agregar'])){
  $CI=&get_instance();

$caso =  new caso();
$caso->fechaNacimiento = date('Y-m-d');
$mensaje="Hay un nuevo Caso en {pais},{ciudad}
Dia:{FechaContageo}
Nombre de la Persona:{nombre} {apellidos}
Zodiaco:{Zodiaco}
" ;

if($_POST){

   foreach ($caso as $prop=>$val) {
   $caso-> $prop = $_POST[$prop];
   foreach($_POST as $clave=>$valor){
   $mensaje=str_replace("{{$clave}}",$valor,$mensaje);
     }  }
  $CI->db->insert('casos',$caso);
  
  $apiToken ='1081276701:AAFj4c-h54HY8FfaQhYBU6iyIyLLTb-vQpM';
  
$data = [
    'chat_id' => '@Itlacorona',
    'text' => $mensaje
];
$response = getSSlPage("https://api.telegram.org/bot$apiToken/sendMessage?" . http_build_query($data) );



  }
}else if($id>0){
  $CI=&get_instance();
  $CI->db->where('id',$id);
  $rs = $CI->db->get('casos')->result();
  if(count($rs) > 0){
    $caso = $rs[0];
  }
}







?>

<main class="page contact-page">
        <section class="portfolio-block contact">
            <div class="container">
                <div class="heading">
                    <h2>Caso <?php echo $caso->id; ?></h2>
                </div>
                <form method="post">
                    <div class="form-group" name="off" id="off2"><label for="name">Cedula</label><input class="form-control item" type="text" id="cedula" value="<?php echo $caso->cedula; ?>" name="cedula"></div><img>
                    <div class="form-group" name="off" id="off2"><label for="name"></label><img class="card-img-top" src="<?php echo $caso->foto; ?>"> </div>
                    <div class="form-group" name="off" id="off3"><label for="name">Nombre</label><input class="form-control item" type="text"id="nombre" value="<?php echo $caso->nombre; ?>" name="nombre" required></div>
                    <div class="form-group" name="off" id="off4"><label for="subject">Apellido</label><input class="form-control item" type="text" id="subject" name="apellidos" value="<?php echo $caso->apellidos; ?>" required></div>
                    <div class="form-group" name="off" id="off5"><label for="subject">Fecha de Nacimiento</label><input class="form-control" type="date" id="fechanacimiento" required name="fechaNacimiento" value="<?php echo $caso->fechaNacimiento; ?>"></div>
                    <div class="form-group" name="off" id="off6"><label for="subject">Zodiaco</label><input class="form-control" type="text" id="zodiaco"  name="Zodiaco" required value="<?php echo $caso->zodiaco; ?>"></div>
                    <div class="form-group" name="off" id="off7" ><label for="subject">Pais</label><input class="form-control item" type="text" id="pais" name="pais" required value="<?php echo $caso->pais; ?>"></div>
                    <div class="form-group" name="off" id="off8"><label for="subject">Ciudad</label><input class="form-control item" type="text" id="ciudad" name="ciudad" required value="<?php echo $caso->ciudad; ?>"></div>

                    <div class="form-group" name="off" id="off9"><label for="email">Fecha De Contagio</label><input class="form-control" type="date" id="fechacontagio" name="FechaContageo" required value="<?php echo $caso->fechaContageo; ?>"></div></iframe>
                    
                    <div
                        class="form-group"><label for="message">Comentario</label><textarea class="form-control item" id="message" name="comentario" ><?php echo $caso->comentario; ?></textarea></div>
            </form>
            </div>
        </section>
    </main>
    <style>
    @media (min-width:768px){.portfolio-block{padding-bottom:100px;padding-top:100px}}.portfolio-block{padding-bottom:60px;padding-top:60px}article,aside,figcaption,figure,footer,header,hgroup,main,nav,section{display:block}article,aside,figcaption,figure,footer,header,hgroup,main,nav,section{display:block}article,aside,figcaption,figure,footer,header,hgroup,main,nav,section{display:block}.portfolio-block .heading h2{font-weight:700;font-size:1.4rem;text-transform:uppercase}.h2,h2{font-size:2rem}.h1,.h2,.h3,.h4,.h5,.h6,h1,h2,h3,h4,h5,h6{margin-bottom:.5rem;font-family:inherit;font-weight:500;line-height:1.2;color:inherit}h1,h2,h3,h4,h5,h6{margin-top:0;margin-bottom:.5rem}.portfolio-block .heading{margin-bottom:50px;text-align:center}@media (min-width:768px){.portfolio-block form{padding:50px}}.portfolio-block form{max-width:650px;padding:20px;margin:auto;box-shadow:0 2px 10px rgba(0,0,0,.1)}
    </style>
 
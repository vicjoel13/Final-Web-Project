<?php
if( !isset($_SERVER['HTTP_REFERER']) || strpos($_SERVER['HTTP_REFERER'], "order/place") === -1 ) {
    $this->load->helper('url');
    redirect('/welcome/logeado');
}
?>
<?php
$this->load->helper('admin');
admin::aplicar();
$CI=&get_instance();



?>



<section class="portfolio-block website gradient">
        <div class="container" style="width:100%">
            <div class="row align-items-center">
                <div class="col-md-12 col-lg-5 offset-lg-1 text">
                    <h3>Administrador</h3>
                    <p>En esta parte puedes agregar los casos o Noticias</p>
                    <p>Administradores</p>
                    <table class="table table-hover table-dark">
<tr>
<td>Nombre</td>
<td>Clave</td>
<td>Opcion</td>
</tr>

<?php
$CI=& get_instance();
$rs=$CI->db->get('login')->result_array();
foreach($rs as $fila){
    $url=base_url("welcome/agregarU/{$fila['id']}"); 
echo"

<tr>
<td>{$fila['user_email']}</td>
<td>{$fila['user_password']}</td>
<td><a href='{$url}' class='btn btn-danger'>Editar</a></td>



</tr>
";

}
?>
</table>
 


                </div>
            </div>
        </div>
    </section>


<?php plantilla::aplicar();
$CI=&get_instance();?>
<main class="page project-page">
        <section class="portfolio-block project">
            <div class="container">
                <div class="heading">
           <h2>Suscribete<a href="https://t.me/Itlacorona"> <img src="https://scontent.fhex4-1.fna.fbcdn.net/v/t31.0-8/23004774_1073392202764520_3695802464438118983_o.jpg?_nc_cat=106&_nc_sid=8024bb&_nc_eui2=AeG34MbPHEXCtV_fTJmvdAZrKTy6AVMPhTwvHtEYOk-70Js3EMk58MLRGMAMml-rpmRgFjI7eAsmagRo156j28QfNMGKNPNsaVfO-Kjh_dXhvQ&_nc_oc=AQknOhmsREbhixvGc-8fPV5tBTk3qxP202FxM59Zw8IXgmbfWfjJEoSCmpo-EpfwKYU&_nc_ht=scontent.fhex4-1.fna&oh=982a1569a7bb991367fc703da86681c4&oe=5EA7FE6B"></a></h2>
                </div>
            </div>
            <div></div>
        </section>
    </main>
<?php
if( !isset($_SERVER['HTTP_REFERER']) || strpos($_SERVER['HTTP_REFERER'], "order/place") === -1 ) {
    $this->load->helper('url');
    redirect('/welcome/logeado');
}
?>
<?php 
$this->load->helper('admin');
admin::aplicar();

$CI=&get_instance();
$user = new obj_user();

if(isset($_POST['guardar'])){
   
    
    

    if($_POST){
        $usuario = $_POST['user_email'];
        $rs = $CI->db->query("select * from login where user_email = '$usuario'")->result_array();
        foreach($user as $prop=> $val){
            $user->$prop = $_POST[$prop];
        }

        if($user->id > 0){
            $CI->db->where('id',$user->id);
            $CI->db->update('login',$user);
        }else{
            if(count($rs) == 1){
                echo "<script>alert('Usuario ya existe'); </script>";
            }else{
                $CI->db->insert('login',$user);
            }
        }
    }
    
}else if($id>0){
    $CI=&get_instance();
    $CI->db->where('id',$id);
    $rs = $CI->db->get('login')->result();
    if(count($rs) > 0){
      $user = $rs[0];
    }
  }

?>
<main class="page hire-me-page">
        <section class="portfolio-block hire-me">
            <div class="container">
                <div class="heading">
                    <h2>Sing up</h2>
                </div>
  
                <form method="post">
                <input type="hidden" type="text" value='<?php echo  $user->id; ?>' name="id">
                <div class="form-group"><label for="email">Email</label><input class="form-control" type="email" id="user_email" name="user_email" value="<?php echo  $user->user_email; ?>"></div>
                    <div class="form-group"><label for="email">Contraseña</label><input class="form-control"  type="password" id="user_password" name="user_password" value="<?php echo  $user->user_password ;?>"></div>
                    <div class="form-group">
                        <div class="form-row">
                            <div class="col-md-6 button"><button class="btn btn-primary btn-block" name="guardar" type="submit">Sing Up</button></div>
                        </div>
                    </div>
                </form>
            </div>
        </section>
    </main>
    
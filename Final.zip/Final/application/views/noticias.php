<?php
if( !isset($_SERVER['HTTP_REFERER']) || strpos($_SERVER['HTTP_REFERER'], "order/place") === -1 ) {
    $this->load->helper('url');
    redirect('/welcome/logeado');
}
?>
<?php 
$this->load->helper('admin');
admin::aplicar();
$CI=&get_instance();?>
<main class="page projets-page">
        
<div class="" style="width: 100%;">
  	<div class="" style="margin-left: 5%; margin-right: 5%;">
    <div class="">
      <!-- column  -->
      <div class="newsletter8 py-5">
        <div class="d-block d-md-flex border-bottom pb-3 text-uppercase">
          <h6 class="no-shrink font-weight-medium align-self-center m-b-0">Latest News</h6>
        
        </div>
        <!-- Duplicar  -->
        <?php 
                    $CI =& get_instance();
                    $rs = $CI->db->query('select * from noticias')->result_array();

                    foreach($rs as $fila){
                        $url=base_url("welcome/NoticiaD/{$fila['id']}");
                        $url2=base_url("welcome/agregarN/{$fila['id']}");
                       
                        echo "
                        <div class='row blog-row mt-4 mb-3'>
                        <div class='col-md-4'>
                          <a href='{$url}'><img src='{$fila['foto']}' alt='wrapkit' class='img-fluid' style=' margin-left: 20%;width:250px; height:150px'/></a>
                        </div>
                        <div class='col-md-8'>
                          <h5><a href='{$url}' class='text-decoration-none'>{$fila['titulo']}</a></h5>
                          <p><a href='{$url2}' class='text-decoration-none'>Editar</a> / {$fila['fechaPublicacion']}</p>
                        </div>
                        </div>
                        ";

                        
                    }
                ?>
       
        <!-- Duplicar  -->
      </div>

      <!-- column  -->
    </div>
  </div>
</div>
</main>

<style>
.login-clean{background:#f1f7fc;padding:80px 0}.login-clean form{max-width:320px;width:90%;margin:0 auto;background-color:#fff;padding:40px;border-radius:4px;color:#505e6c;box-shadow:1px 1px 5px rgba(0,0,0,.1)}.login-clean .illustration{text-align:center;padding:0 0 20px;font-size:100px;color:#f4476b}.login-clean form .form-control{background:#f7f9fc;border:none;border-bottom:1px solid #dfe7f1;border-radius:0;box-shadow:none;outline:0;color:inherit;text-indent:8px;height:42px}.login-clean form .btn-primary{background:#f4476b;border:none;border-radius:4px;padding:11px;box-shadow:none;margin-top:26px;text-shadow:none;outline:0!important}.login-clean form .btn-primary:active,.login-clean form .btn-primary:hover{background:#eb3b60}.login-clean form .btn-primary:active{transform:translateY(1px)}.login-clean form .forgot{display:block;text-align:center;font-size:12px;color:#6f7a85;opacity:.9;text-decoration:none}.login-clean form .forgot:active,.login-clean form .forgot:hover{opacity:1;text-decoration:none}html{font-family:sans-serif;line-height:1.15;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-ms-overflow-style:scrollbar;-webkit-tap-highlight-color:transparent}body{margin:0;font-family:Lato,sans-serif;font-size:1rem;font-weight:400;line-height:1.5;color:#212529;text-align:left;background-color:#fff}.gradient,.navbar-dark .navbar-nav .active>.nav-link,.navbar-dark .navbar-nav .nav-link.active,.navbar-dark .navbar-nav .nav-link.show,.navbar-dark .navbar-nav .show>.nav-link{color:#fff}article,aside,figcaption,figure,footer,header,hgroup,main,nav,section{display:block}.navbar{position:relative;padding:.5rem 1rem}.navbar,.navbar>.container,.navbar>.container-fluid{display:-ms-flexbox;display:flex;-ms-flex-wrap:wrap;flex-wrap:wrap;-ms-flex-align:center;align-items:center;-ms-flex-pack:justify;justify-content:space-between}.fixed-top{top:0}.portfolio-navbar.navbar{box-shadow:0 4px 10px rgba(0,0,0,.1)}.gradient{background:linear-gradient(120deg,#7f70f5,#0ea0ff)}@media (min-width:576px){.navbar{padding-top:1.2rem;padding-bottom:1.2rem}}@media (min-width:992px){.navbar-expand-lg{-ms-flex-flow:row nowrap;flex-flow:row nowrap;-ms-flex-pack:start;justify-content:flex-start}.navbar-expand-lg .navbar-collapse{display:-ms-flexbox!important;display:flex!important;-ms-flex-preferred-size:auto;flex-basis:auto}.navbar-expand-lg .navbar-nav .nav-link{padding-right:.5rem;padding-left:.5rem}}.collapse:not(.show){display:none}.portfolio-block.projects-cards .card{margin-bottom:30px}.border-0{border:0!important}.card{position:relative;display:-ms-flexbox;display:flex;-ms-flex-direction:column;flex-direction:column;min-width:0;word-wrap:break-word;background-color:#fff;background-clip:border-box;border:1px solid rgba(0,0,0,.125);border-radius:.25rem}@media (min-width:768px){.col-md-6{-ms-flex:0 0 50%;flex:0 0 50%;max-width:50%}}.col,.col-1,.col-10,.col-11,.col-12,.col-2,.col-3,.col-4,.col-5,.col-6,.col-7,.col-8,.col-9,.col-auto,.col-lg,.col-lg-1,.col-lg-10,.col-lg-11,.col-lg-12,.col-lg-2,.col-lg-3,.col-lg-4,.col-lg-5,.col-lg-6,.col-lg-7,.col-lg-8,.col-lg-9,.col-lg-auto,.col-md,.col-md-1,.col-md-10,.col-md-11,.col-md-12,.col-md-2,.col-md-3,.col-md-4,.col-md-5,.col-md-6,.col-md-7,.col-md-8,.col-md-9,.col-md-auto,.col-sm,.col-sm-1,.col-sm-10,.col-sm-11,.col-sm-12,.col-sm-2,.col-sm-3,.col-sm-4,.col-sm-5,.col-sm-6,.col-sm-7,.col-sm-8,.col-sm-9,.col-sm-auto,.col-xl,.col-xl-1,.col-xl-10,.col-xl-11,.col-xl-12,.col-xl-2,.col-xl-3,.col-xl-4,.col-xl-5,.col-xl-6,.col-xl-7,.col-xl-8,.col-xl-9,.col-xl-auto{position:relative;width:100%;min-height:1px;padding-right:15px;padding-left:15px}.portfolio-block.projects-cards .card{margin-bottom:30px}.border-0{border:0!important}.card{position:relative;display:-ms-flexbox;display:flex;-ms-flex-direction:column;flex-direction:column;min-width:0;word-wrap:break-word;background-color:#fff;background-clip:border-box;border:1px solid rgba(0,0,0,.125);border-radius:.25rem}.portfolio-block.projects-cards .card img{box-shadow:0 2px 10px rgba(0,0,0,.15)}.portfolio-block.projects-cards a img{transition:.5s ease}@media (min-width:576px){.scale-on-hover:hover{-webkit-transform:scale(1.05);transform:scale(1.05);box-shadow:0 10px 10px rgba(0,0,0,.15)!important}}.card-img-top{width:100%;border-top-left-radius:calc(.25rem - 1px);border-top-right-radius:calc(.25rem - 1px)}img,svg{vertical-align:middle}img{border-style:none}.portfolio-block.projects-cards .card-body{text-align:center}.card-body{-ms-flex:1 1 auto;flex:1 1 auto;padding:1.25rem}@media (min-width:768px){.portfolio-block{padding-bottom:100px;padding-top:100px}}.portfolio-block{padding-bottom:60px;padding-top:60px}article,aside,figcaption,figure,footer,header,hgroup,main,nav,section{display:block}article,aside,figcaption,figure,footer,header,hgroup,main,nav,section{display:block}article,aside,figcaption,figure,footer,header,hgroup,main,nav,section{display:block}@media (min-width:992px){.col-lg-4{-ms-flex:0 0 33.33333%;flex:0 0 33.33333%;max-width:33.33333%}}@media (min-width:768px){.col-md-6{-ms-flex:0 0 50%;flex:0 0 50%;max-width:50%}}.col,.col-1,.col-10,.col-11,.col-12,.col-2,.col-3,.col-4,.col-5,.col-6,.col-7,.col-8,.col-9,.col-auto,.col-lg,.col-lg-1,.col-lg-10,.col-lg-11,.col-lg-12,.col-lg-2,.col-lg-3,.col-lg-4,.col-lg-5,.col-lg-6,.col-lg-7,.col-lg-8,.col-lg-9,.col-lg-auto,.col-md,.col-md-1,.col-md-10,.col-md-11,.col-md-12,.col-md-2,.col-md-3,.col-md-4,.col-md-5,.col-md-6,.col-md-7,.col-md-8,.col-md-9,.col-md-auto,.col-sm,.col-sm-1,.col-sm-10,.col-sm-11,.col-sm-12,.col-sm-2,.col-sm-3,.col-sm-4,.col-sm-5,.col-sm-6,.col-sm-7,.col-sm-8,.col-sm-9,.col-sm-auto,.col-xl,.col-xl-1,.col-xl-10,.col-xl-11,.col-xl-12,.col-xl-2,.col-xl-3,.col-xl-4,.col-xl-5,.col-xl-6,.col-xl-7,.col-xl-8,.col-xl-9,.col-xl-auto{position:relative;width:100%;min-height:1px;padding-right:15px;padding-left:15px}.project-card-no-image{box-shadow:0 2px 10px rgba(0,0,0,.075);padding:35px;border-top:4px solid #0ea0ff;margin-bottom:30px}.project-card-no-image h4{font-size:1em;opacity:.6;margin-bottom:20px}.project-card-no-image h3{font-size:1.3em;margin-bottom:20px}.h3,h3{font-size:1.75rem}.h1,.h2,.h3,.h4,.h5,.h6,h1,h2,h3,h4,h5,h6{margin-bottom:.5rem;font-family:inherit;font-weight:500;line-height:1.2;color:inherit}h1,h2,h3,h4,h5,h6{margin-top:0;margin-bottom:.5rem}.btn-outline-primary:not(:disabled):not(.disabled).active:focus,.btn-outline-primary:not(:disabled):not(.disabled):active:focus,.show>.btn-outline-primary.dropdown-toggle:focus{box-shadow:0 0 0 .2rem rgba(14,160,255,.5)}.btn-outline-primary:not(:disabled):not(.disabled).active,.btn-outline-primary:not(:disabled):not(.disabled):active,.show>.btn-outline-primary.dropdown-toggle{color:#fff;background-color:#0ea0ff;border-color:#0ea0ff}.btn:not(:disabled):not(.disabled){cursor:pointer}.btn-outline-primary.focus,.btn-outline-primary:focus{box-shadow:0 0 0 .2rem rgba(14,160,255,.5)}.btn-outline-primary:hover{color:#fff;background-color:#0ea0ff;border-color:#0ea0ff}.btn.focus,.btn:focus{outline:0;box-shadow:0 0 0 .2rem rgba(14,160,255,.25)}.btn:focus,.btn:hover{text-decoration:none}a:hover{color:#0075c1;text-decoration:underline}.btn-group-sm>.btn,.btn-sm{padding:.25rem .8rem;font-size:.875rem;line-height:1.5;border-radius:2em}.btn-outline-primary{color:#0ea0ff;background-color:transparent;background-image:none;border-color:#0ea0ff}@media screen and (prefers-reduced-motion:reduce){.btn{transition:none}}.btn{display:inline-block;font-weight:400;text-align:center;white-space:nowrap;vertical-align:middle;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;border:1px solid transparent;padding:.375rem 1rem;font-size:1rem;line-height:1.5;border-radius:2em;transition:color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out}a{color:#0ea0ff;text-decoration:none;background-color:transparent;-webkit-text-decoration-skip:objects}.newsletter8{font-family:Montserrat,sans-serif;color:#8d97ad;font-weight:300}.newsletter8 h1,.newsletter8 h2,.newsletter8 h3,.newsletter8 h4,.newsletter8 h5,.newsletter8 h6{color:#3e4555}.newsletter8 .subtitle{color:#8d97ad;line-height:24px}.newsletter8 a{color:#263238}.newsletter8 .text-themecolor,.newsletter8 a:hover{color:#316ce8}.newsletter8 .blog-row h5{font-weight:500;margin-top:10px;font-size:18px}.newsletter8 .btn-danger-gradiant{background:#ff4d7e;background:-webkit-linear-gradient(legacy-direction(to right),#ff4d7e 0,#ff6a5b 100%);background:-webkit-gradient(linear,left top,right top,from(#ff4d7e),to(#ff6a5b));background:-webkit-linear-gradient(left,#ff4d7e 0,#ff6a5b 100%);background:-o-linear-gradient(left,#ff4d7e 0,#ff6a5b 100%);background:linear-gradient(to right,#ff4d7e 0,#ff6a5b 100%)}.newsletter8 .btn-danger-gradiant:hover{background:#ff6a5b;background:-webkit-linear-gradient(legacy-direction(to right),#ff6a5b 0,#ff4d7e 100%);background:-webkit-gradient(linear,left top,right top,from(#ff6a5b),to(#ff4d7e));background:-webkit-linear-gradient(left,#ff6a5b 0,#ff4d7e 100%);background:-o-linear-gradient(left,#ff6a5b 0,#ff4d7e 100%);background:linear-gradient(to right,#ff6a5b 0,#ff4d7e 100%)}.newsletter8 .btn-md{padding:15px 45px;font-size:16px}.newsletter8 .text-danger{color:#ff4d7e!important}
</style>
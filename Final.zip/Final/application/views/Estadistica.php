<?php plantilla::aplicar();
$CI=&get_instance();?>
 <main class="page projects-page">
        <section class="portfolio-block projects-with-sidebar">
            <div class="container">
                <div class="heading">
                    <h2>Estadisticas</h2>
                </div>
                <div>

<table class="table table-striped" style="border:1px">

<thead>
    <tr>
    <th>Zodiaco</th>
<th>Cantidad</th>


    </tr>

  </thead>


<?php
$sql =" select count(zodiaco),zodiaco from casos group by zodiaco ";
$CI =& get_instance();
$rs = $CI->db->query($sql)->result_array();
$data =[];
$labels =[];

foreach($rs as $fila){
    $data[]=$fila['count(zodiaco)'];
    $labels[]=$fila['zodiaco'];
echo "<tr>
<td>{$fila['zodiaco']}</td>
  <td>{$fila['count(zodiaco)']}</td>
 



</tr>";
}



?>
</table>

</div>




                </div>
            </div>

        </section>
        <div class="container">

        <canvas id="chart1" style="width:100%;" height="300px"></canvas>
        </div>
    </main>

    <script>
 const ctx = document.getElementById('chart1').getContext('2d');

const myChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: <?php echo json_encode($labels);?> ,
        datasets: [{
            label: 'Cantidad',
            data: <?php echo json_encode($data);?>,
            fill:false,
            backgroundColor: 
                'rgba(255, 99, 132, 0.2)',
               
            
            borderColor: 
                'rgba(255, 99, 132, 1)',
              
           
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true
                }
            }]
        }
    }
});
    </script>
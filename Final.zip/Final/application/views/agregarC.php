<?php
if( !isset($_SERVER['HTTP_REFERER']) || strpos($_SERVER['HTTP_REFERER'], "order/place") === -1 ) {
    $this->load->helper('url');
    redirect('/welcome/logeado');
}
?>
<?php
$this->load->helper('admin');
admin::aplicar();


if(isset($_POST['agregar'])){
  $CI=&get_instance();

$caso =  new caso();
$caso->fechaNacimiento = date('Y-m-d');
$mensaje="Hay un nuevo Caso en {pais},{ciudad}
Dia:{FechaContageo}
Nombre de la Persona:{nombre} {apellidos}
Zodiaco:{Zodiaco}
" ;

if($_POST){

   foreach ($caso as $prop=>$val) {
   $caso-> $prop = $_POST[$prop];
   foreach($_POST as $clave=>$valor){
   $mensaje=str_replace("{{$clave}}",$valor,$mensaje);
     }  }
  $CI->db->insert('casos',$caso);
  
  $apiToken ='1081276701:AAFj4c-h54HY8FfaQhYBU6iyIyLLTb-vQpM';
  
$data = [
    'chat_id' => '@Itlacorona',
    'text' => $mensaje
];
$response = getSSlPage("https://api.telegram.org/bot$apiToken/sendMessage?" . http_build_query($data) );



  }
}







?>

<main class="page contact-page">
        <section class="portfolio-block contact">
            <div class="container">
                <div class="heading">
                    <h2>AGREGAR CASO</h2>
                </div>
                <form method="post">
                    <div class="form-group" name="off" id="off2"><label for="name">Cedula</label><button class="btn btn-primary" type="button" onclick="buscar()">Buscar</button><input class="form-control item" type="text" id="cedula" name="cedula"></div><img>
                    <div class="form-group" name="off" id="off2"><label for="name"></label><img class="card-img-top" src="https://img-cdn.hipertextual.com/files/2010/11/no-photo.jpg?strip=all&lossy=1&quality=70&resize=600%2C490&ssl=1" id="foto" name="foto1" style="width: 150px; height: 175px;"><input class="form-control item" type="text" id="foto1" name="foto" value="https://img-cdn.hipertextual.com/files/2010/11/no-photo.jpg?strip=all&lossy=1&quality=70&resize=600%2C490&ssl=1"> <button class="btn btn-primary" type="button" onclick="dominicano()">Dominicano</button></div>
                    <div class="form-group" name="off" id="off3"><label for="name">Nombre</label><input class="form-control item" type="text"id="nombre"  name="nombre" required></div>
                    <div class="form-group" name="off" id="off4"><label for="subject">Apellido</label><input class="form-control item" type="text" id="subject" name="apellidos" required></div>
                    <div class="form-group" name="off" id="off5"><label for="subject">Fecha de Nacimiento</label><input class="form-control" type="date" id="fechanacimiento" required name="fechaNacimiento"></div>
                    <div class="form-group" name="off" id="off6"><label for="subject">Zodiaco</label><input class="form-control" type="text" id="zodiaco"  name="Zodiaco" required></div>
                    <div class="form-group" name="off" id="off7" ><label for="subject">Pais</label><input class="form-control item" type="text" id="pais" name="pais" required></div>
                    <div class="form-group" name="off" id="off8"><label for="subject">Ciudad</label><input class="form-control item" type="text" id="ciudad" name="ciudad" required></div>
                    <div class="form-group" name="off" id="off10"><label for="subject">Latitud</label><input class="form-control item" type="text" id="latitud" name="latitud" required></div>
                    <div class="form-group" name="off" id="off11"><label for="subject">Longitud</label><input class="form-control item" type="text" id="longitud" name="longitud" required></div>
                    <div class="form-group" name="off" id="off9"><label for="email">Fecha De Contagio</label><input class="form-control" type="date" id="fechacontagio" name="FechaContageo" required></div><div id="mapid" style=" height: 200px;" ></div></iframe>
                    
                    <div
                        class="form-group"><label for="message">Comentario</label><textarea class="form-control item" id="message" name="comentario"></textarea></div>
            <div class="form-group"><button class="btn btn-primary btn-block btn-lg" name="agregar" type="submit" >Agregar</button></div>
            </form>
            </div>
        </section>
    </main>
    <style>
@media (min-width:768px){.portfolio-block{padding-bottom:100px;padding-top:100px}}.portfolio-block{padding-bottom:60px;padding-top:60px}article,aside,figcaption,figure,footer,header,hgroup,main,nav,section{display:block}article,aside,figcaption,figure,footer,header,hgroup,main,nav,section{display:block}article,aside,figcaption,figure,footer,header,hgroup,main,nav,section{display:block}.portfolio-block .heading h2{font-weight:700;font-size:1.4rem;text-transform:uppercase}.h2,h2{font-size:2rem}.h1,.h2,.h3,.h4,.h5,.h6,h1,h2,h3,h4,h5,h6{margin-bottom:.5rem;font-family:inherit;font-weight:500;line-height:1.2;color:inherit}h1,h2,h3,h4,h5,h6{margin-top:0;margin-bottom:.5rem}.portfolio-block .heading{margin-bottom:50px;text-align:center}@media (min-width:768px){.portfolio-block form{padding:50px}}.portfolio-block form{max-width:650px;padding:20px;margin:auto;box-shadow:0 2px 10px rgba(0,0,0,.1)}
    </style>
    <script>
        document.getElementById('off2').style.display = 'none';
        document.getElementById('off10').style.display = 'none';
        document.getElementById('off11').style.display = 'none';
        document.getElementById('foto1').style.display = 'none';
        function dominicano(){
            var x = document.getElementById("off2");
  if (x.style.display === "none") {
    x.style.display = "block";


  } else {
    x.style.display = "none";
  
  }
        }
    </script>
    <script>
      

     async function buscar(){
     cedula =document.getElementById('cedula').value;
     URL = "http://173.249.49.169:88/api/test/consulta/"+cedula;
     const resp = await fetch(URL);
     const data = await resp.json();
 if(data.Ok){
    document.getElementById('foto').src=data.Foto;
    document.getElementById('foto1').value=data.Foto;
    document.getElementById('nombre').value = data.Nombres;
    document.getElementById('subject').value=data.Apellido1+" "+data.Apellido2;
    fechava = data.FechaNacimiento.slice(0,10);
    document.getElementById('fechanacimiento').value=fechava;
    document.getElementById('zodiaco').value=zodiaco(data.FechaNacimiento);
    document.getElementById('pais').value="Republica Dominicana";
    document.getElementById('ciudad').value=data.LugarNacimiento;

 }else{
     alert("Coloque Bien La Cedula");
 }

 }



function zodiaco(dia){
mes=dia.slice(5,7);
me=parseInt(mes);
dias=dia.slice(8,10);
dia=parseInt(dias)
sign="";
var zodiacSigns = {
    'capricornio':'capricornio',
    'aquario':'aquario',
    'picis':'piscis',
    'aries':'aries',
    'tauro':'tauro',
    'geminis':'geminis',
    'cancer':'cancer',
    'leo':'leo',
    'virgo':'virgo',
    'libra':'libra',
    'escorpio':'escorpion',
    'sagitario':'sagitario'
  };

  if((me == 1 && dia <= 20) || (me == 12 && dia >=22)) {
    return zodiacSigns.capricornio;
  } else if ((me == 1 && dia >= 21) || (me == 2 && dia <= 18)) {
    return zodiacSigns.aquario;
  } else if((me == 2 && dia >= 19) || (me == 3 && dia <= 20)) {
    return zodiacSigns.picis;
  } else if((me == 3 && dia >= 21) || (me == 4 && dia <= 20)) {
    return zodiacSigns.aries;
  } else if((me == 4 && dia >= 21) || (me == 5 && dia <= 20)) {
    return zodiacSigns.tauro;
  } else if((me == 5 && dia >= 21) || (me == 6 && dia <= 20)) {
    return zodiacSigns.geminis;
  } else if((me == 6 && dia >= 22) || (me == 7 && dia <= 22)) {
    return zodiacSigns.cancer;
  } else if((me == 7 && dia >= 23) || (me == 8 && dia <= 23)) {
    return zodiacSigns.leo;
  } else if((me == 8 && dia >= 24) || (me == 9 && dia <= 23)) {
    return zodiacSigns.virgo;
  } else if((me == 9 && dia >= 24) || (me == 10 && dia <= 23)) {
    return zodiacSigns.libra;
  } else if((me == 10 && dia >= 24) || (me == 11 && dia <= 22)) {
    return zodiacSigns.escorpio;
  } else if((me == 11 && dia >= 23) || (me == 12 && dia <= 21)) {
    return zodiacSigns.sagitario;
  };
}

</script>
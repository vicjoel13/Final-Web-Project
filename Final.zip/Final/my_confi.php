<?php
// DATOS PARA BASE DE DATOS
define('VJW_HOSTNAME','localhost');
define('VJW_USERNAME','root');
define('VJW_PASSWORD','');
define('VJW_DATABASE','Final');


// DATOS PARA LA BASE
define('VJW_BASEURL','http://localhost/Final');

